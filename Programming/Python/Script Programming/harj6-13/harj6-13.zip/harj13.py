def dog_sleeps(x, y):
	print(x, "nukkuu päivästä", y, "tuntia\n")

def dog_walks(x, y):
	print(x, "kävelee ", y, "kilometria tunnissa\n")

def dog_runs(x, y):
	print(x, "juoksee" , y, "kilometria tunnissa\n" )

def dog_barks(x, y):
	print(x, "sanoo", y)
nimi = "Sera"
uni = 10
kavely = 4
juoksu =  15
aani = "hau hau"
dog_sleeps(nimi, 10)
dog_walks(nimi, kavely)
dog_runs(nimi, juoksu)
dog_barks(nimi, aani)

