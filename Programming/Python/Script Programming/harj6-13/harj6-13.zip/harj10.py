def reverse(lista):
        for x in lista[::-1]:
                reverselista.append(x)
        return(reverselista)
reverselista=[]
print(reverse([1,2,3,4,5]))