def sum(lista):
	summa = 0
	for x in lista:
		summa = summa + x
	return(summa)

lista=[1,2,3,4,5]
print(sum(lista))
