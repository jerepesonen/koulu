persons = ["alice", "bob", "craig", "dave", "elisabeth", "frank", "george" ]
for x in persons:
	print(persons.index(x),x)

