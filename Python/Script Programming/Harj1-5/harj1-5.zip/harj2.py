
luku = 1
lkm = luku
kirjain="A"

while luku < 10:
	while lkm > 0:
		print(kirjain, end = '')
		lkm -= 1
	print("")
	luku += 1
	lkm = luku