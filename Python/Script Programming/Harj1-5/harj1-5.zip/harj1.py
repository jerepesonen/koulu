greeting="hello world!"

for x in greeting:
	print(x)